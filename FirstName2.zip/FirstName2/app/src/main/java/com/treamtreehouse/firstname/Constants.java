package com.treamtreehouse.firstname;

public class Constants {
    public static final String KEY_2 = "value";

}
