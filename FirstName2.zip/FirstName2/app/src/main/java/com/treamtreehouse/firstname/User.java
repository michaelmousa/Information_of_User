package com.treamtreehouse.firstname;

import android.os.Parcel;
import android.os.Parcelable;
public class User implements Parcelable{

    private String FirstNamee;
    private String MiddleName;
    private String LastName;

    public String getFirstNamee() { return FirstNamee; }

    public void setFirstNamee(String firstNamee) { this.FirstNamee = firstNamee; }

    public String getMiddleName() { return MiddleName; }

    public void setMiddleName(String middleName) { MiddleName = middleName; }

    public String getLastName() { return LastName; }

    public void setLastName(String lastName) { this.LastName = lastName; }

    public User(String FristNamee, String MiddleName, String LastName){
        this.FirstNamee = FirstNamee;
        this.MiddleName = MiddleName;
        this.LastName = LastName;
    }
    protected User (Parcel in){

    }
    @Override
    public void writeToParcel(Parcel dest , int flags) {
        dest.writeString ( FirstNamee );
        dest.writeString ( MiddleName );
        dest.writeString (LastName  );
    }

    @Override
    public int describeContents() { return 0;}

    public static final Creator<User> CREATOR = new Creator<User>() {
        @Override
        public User createFromParcel(Parcel in) { return new User(in); }

        @Override
        public User[] newArray(int size) { return new User[size]; }
    };
    public int describeContent(){ return 0; }

    @Override
    public String toString() {
        return "User{" + "FirstName='" + FirstNamee + '\'' +
                ", MiddleName='" + MiddleName + '\'' +", " +
                "LastName='" + LastName + '\'' +
                '}';
    }
}