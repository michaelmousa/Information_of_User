package com.treamtreehouse.firstname;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Parcelable;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.nio.charset.Charset;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class MainActivity extends AppCompatActivity {

    private final String TAG = "MainActivity";
    private EditText FirstNamee, MiddleName, LastName;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate ( savedInstanceState );
        setContentView ( R.layout.activity_main );
        FirstNamee = findViewById ( R.id.FrisNamee );
        MiddleName = findViewById ( R.id.MiddName );
        LastName = findViewById ( R.id.LastName );
        Log.d ( TAG , "onGreate" );
    }
    @Override
    protected void onStart() { super.onStart ();
        Log.d ( TAG , "onStart: " );
    }
    @Override
    protected void onResume() { super.onResume ();
        Log.d ( TAG , "onResume: " );
    }
    @Override
    protected void onStop() { super.onStop ();
        Log.d ( TAG , "onStop: " );
    }
    @Override
    protected void onDestroy() { super.onDestroy ();
        Log.d ( TAG , "onDestroy: " );
    }
    @Override
    protected void onRestart() { super.onRestart ();
        Log.d ( TAG , "onRestart: " );
    }
    @Override
    protected void onPause() { super.onPause ();
        Log.d ( TAG , "onPause: " );
    }


    public void doSomeThing(View view) throws NoSuchAlgorithmException

    {
        switch (view.getId ())
        {
            case    R.id.btnSavetoSharePref:
                SharedPreferences sharedPreferences = getSharedPreferences ( "sp", MODE_PRIVATE );
                SharedPreferences.Editor editor = sharedPreferences.edit ();
                editor.putString ( "FirstNamee" , FirstNamee.getText ().toString () );
                editor.putString ( "MiddleName" , MiddleName.getText ().toString () );
                editor.putString ( "LastName" , LastName.getText ().toString () );
                editor.commit ();
                Intent intent1 = new Intent ( this , SecondActivity.class );
                intent1.setAction ( "sharedPrefs" );
                startActivity ( intent1 );
                break;

        }

    }
    private String getMessageDigest(String string) throws NoSuchAlgorithmException {
        MessageDigest messageDigest = MessageDigest.getInstance ( "SHA-256" );
        messageDigest.reset ();
        messageDigest.reset ();
        messageDigest.update ( string.getBytes ( Charset.forName ( "UTF-8" ) ) );
        StringBuilder hexString = new StringBuilder ();
        byte[] messageDigestArray = messageDigest.digest ();
        for (int i = 0; i < messageDigestArray.length; i++) {
            hexString.append ( Integer.toHexString ( 0xFF & messageDigestArray[i] ) );
        }
        return hexString.toString ();



    }

}


