package com.treamtreehouse.firstname;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.List;

public class SecondActivity extends AppCompatActivity {
private static final String TAG = "SecondActivity";
private TextView FirstNamee, MiddleName, LastName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate ( savedInstanceState );
        setContentView ( R.layout.activity_second );


        FirstNamee = findViewById ( R.id.FrisNamee );
        MiddleName = findViewById ( R.id.MiddName );
        LastName = findViewById ( R.id.LastName );

    }
    protected void onResume() {
        super.onResume ();
    switch (getIntent ().getAction ()) {
    case "sharedPrefs":
        SharedPreferences sharedPreferences = getSharedPreferences ( "sp" , MODE_PRIVATE );
        String firstNamee = sharedPreferences.getString ( "FirstNamee" , "");
        String middleName = sharedPreferences.getString ("MiddleName" , "");
        String lastName =sharedPreferences.getString ("LastName", "");
        FirstNamee.setText ( firstNamee );
        MiddleName.setText (middleName);
        LastName.setText (lastName);
        break;
}}

}

